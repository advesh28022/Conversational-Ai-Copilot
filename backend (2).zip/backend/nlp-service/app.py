import os
import certifi
from flask import Flask, request, jsonify
from flask_cors import CORS
import json
from datetime import datetime

# Set Ollama connection and SSL settings
os.environ["OLLAMA_HOST"] = "http://localhost:11434"
os.environ['SSL_CERT_FILE'] = certifi.where()

try:
    import ollama
except ImportError:
    raise RuntimeError("Ollama not installed. Run: pip install ollama")

app = Flask(__name__)
CORS(app)

# Global variable to hold aviation data
AVIATION_DATA = None

def load_aviation_data(filename='business_data.json'):
    global AVIATION_DATA
    try:
        with open(filename) as f:
            AVIATION_DATA = json.load(f)
        print("Aviation data loaded successfully")
        return True
    except Exception as e:
        print(f"Error loading aviation data: {e}")
        AVIATION_DATA = {"error": "Data not loaded"}
        return False

def generate_visualization(query: str) -> dict:
    if not AVIATION_DATA or 'error' in AVIATION_DATA:
        return {}
    
    try:
        # Clean the query by removing special characters and arrows
        clean_query = query.lower().replace('→', '').replace('➔', '').strip()
        
        # Search all sections for matching data
        for section in ['cards', 'Parastatal', 'Airlines']:
            for item in AVIATION_DATA.get(section, []):
                # Check if query matches title or any keywords
                item_title = item.get('title', '').lower()
                if (clean_query in item_title or 
                    any(word in clean_query for word in item_title.split()) or
                    any(word in item_title for word in clean_query.split())):
                    
                    if not item.get('kpis') or not item['kpis'][0].get('data'):
                        continue
                    
                    kpi_data = item['kpis'][0]['data']
                    chart_type = item.get('template_type', 'bar').replace('_chart', '')
                    
                    print(f"Generating chart for: {item['title']}")  # Debug log
                    
                    # Handle different chart types
                    if isinstance(kpi_data, dict) and all(isinstance(v, (int, float)) for v in kpi_data.values()):
                        # Pie/Donut chart data (for NSIB, NCAA, Allied Air)
                        return {
                            "type": "doughnut",
                            "data": {
                                "labels": list(kpi_data.keys()),
                                "datasets": [{
                                    "data": list(kpi_data.values()),
                                    "backgroundColor": [
                                        '#3f51b5', '#2196f3', '#00bcd4', 
                                        '#4caf50', '#ff9800', '#9c27b0'
                                    ],
                                    "borderWidth": 1
                                }]
                            },
                            "options": {
                                "responsive": True,
                                "plugins": {
                                    "title": {
                                        "display": True,
                                        "text": item['title'],
                                        "font": {"size": 16}
                                    }
                                }
                            }
                        }
                    elif 'labels' in kpi_data and 'series' in kpi_data:
                        # Line/Bar chart data (for FAAN, Aero, Azman)
                        return {
                            "type": chart_type,
                            "data": {
                                "labels": kpi_data['labels'],
                                "datasets": [{
                                    "label": item['title'],
                                    "data": kpi_data['series'],
                                    "borderColor": "#3f51b5",
                                    "backgroundColor": "#3f51b5" if chart_type == 'bar' else "rgba(63, 81, 181, 0.2)",
                                    "borderWidth": 2,
                                    "fill": chart_type == 'line',
                                    "tension": 0.1
                                }]
                            },
                            "options": {
                                "responsive": True,
                                "plugins": {
                                    "title": {
                                        "display": True,
                                        "text": item['title'],
                                        "font": {"size": 16}
                                    }
                                },
                                "scales": {
                                    "y": {
                                        "beginAtZero": False if chart_type == 'line' else True
                                    }
                                }
                            }
                        }
                    elif 'categories' in kpi_data:
                        # Multi-dataset bar chart (for NAMA, Arik Air)
                        datasets = []
                        colors = ["#3f51b5", "#2196f3", "#00bcd4", "#4caf50"]
                        
                        for i, (key, values) in enumerate(kpi_data.items()):
                            if key != 'categories':
                                datasets.append({
                                    "label": key,
                                    "data": values,
                                    "backgroundColor": colors[i % len(colors)],
                                    "borderColor": colors[i % len(colors)],
                                    "borderWidth": 1
                                })
                        
                        return {
                            "type": "bar",
                            "data": {
                                "labels": kpi_data['categories'],
                                "datasets": datasets
                            },
                            "options": {
                                "responsive": True,
                                "plugins": {
                                    "title": {
                                        "display": True,
                                        "text": item['title'],
                                        "font": {"size": 16}
                                    }
                                },
                                "scales": {
                                    "y": {
                                        "beginAtZero": True
                                    }
                                }
                            }
                        }
        
        print(f"No chart found for query: {query}")  # Debug log
        return {}
    except Exception as e:
        print(f"Visualization error: {e}")
        return {}

def generate_response(query: str) -> dict:
    try:
        # Initial greeting
        if any(word in query.lower() for word in ["hi", "hello", "hey"]):
            return {
                "response": "👋 Hello! I'm your Aviation Ministry AI Co-Pilot. How can I assist you today?",
                "followups": [
                    "Show flight delay trends →",
                    "Analyze airline performance →",
                    "View compliance rates →"
                ],
                "insights": ["Ready to analyze aviation data"]
            }
        
        # Check if data is loaded
        if not AVIATION_DATA or 'error' in AVIATION_DATA:
            return {
                "response": "⚠️ Please load aviation data first.",
                "error": True
            }

        # Generate visualization
        visualization = generate_visualization(query)

        # Generate analysis with Ollama
        prompt = f"""
        You are an aviation data analyst for the Federal Ministry of Aviation. 
        The user asked: "{query}"

        Available data overview:
        - Dashboard title: {AVIATION_DATA.get('title')}
        - User role: {AVIATION_DATA.get('user_role')}
        - Contains {len(AVIATION_DATA.get('cards', []))} main cards
        - {len(AVIATION_DATA.get('Parastatal', []))} parastatal reports
        - {len(AVIATION_DATA.get('Airlines', []))} airline reports

        {f'Visualization context: {json.dumps(visualization.get("options", {}).get("title", {}))}' if visualization else ''}

        Provide a concise response with:
        1. **Key Insight**: 1-2 sentence summary
        2. **Data Points**: Relevant numbers/metrics
        3. **Recommendation**: Actionable suggestion
        """
        
        llm_response = ollama.generate(
            model="mistral",
            prompt=prompt,
            options={"temperature": 0.5}
        )

        return {
            "response": llm_response.get("response", "No analysis generated."),
            "visualization": visualization,
            "followups": [
                "Show detailed breakdown →",
                "Compare with targets →",
                "Export this report →"
            ],
            "insights": [
                "AI-generated aviation analysis",
                "Chart available" if visualization else ""
            ],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        print(f"Response error: {e}")
        return {
            "response": "⚠️ Error processing your request. Please try again.",
            "error": True,
            "insights": []
        }

@app.route('/process', methods=['POST'])
def process():
    try:
        data = request.get_json()
        query = data.get('query', '').strip()

        if not query:
            return jsonify({"error": "Empty query"}), 400

        response = generate_response(query)
        return jsonify(response)

    except Exception as e:
        print(f"API error: {e}")
        return jsonify({
            "response": "⚠️ Internal server error.",
            "error": True
        }), 500

@app.route('/reload-data', methods=['POST'])
def reload_data():
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No file provided"}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
            
        filename = 'business_data.json'
        file.save(filename)
        success = load_aviation_data(filename)
        
        return jsonify({
            "success": success,
            "message": "Data reloaded" if success else "Failed to reload data"
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Verify Ollama is running
    try:
        print("Testing Ollama connection...")
        print("Available models:", ollama.list())
        
        # Load initial data
        load_aviation_data()
        
        # Start Flask app
        app.run(host='0.0.0.0', port=5000, debug=True)
    except Exception as e:
        print(f"Failed to start: {e}")
        print("Make sure Ollama is running (run 'ollama serve' in another terminal)")