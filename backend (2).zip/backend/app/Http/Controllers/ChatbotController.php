<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ChatbotController extends Controller
{
    public function ask(Request $request)
    {
        $query = $request->input('query');

        if (!$query) {
            return response()->json(['error' => 'Query is required.', 'insights' => []], 400);
        }

        try {
            $response = Http::timeout(30)->post('http://localhost:5000/process', [
                'query' => $query
            ]);

            if ($response->successful()) {
                $data = $response->json();
                // Ensure all expected fields exist
                $data['insights'] = $data['insights'] ?? [];
                $data['followups'] = $data['followups'] ?? [];
                return response()->json($data);
            } else {
                return response()->json([
                    'error' => 'AI server error',
                    'details' => $response->body(),
                    'insights' => [],
                    'followups' => []
                ], $response->status());
            }

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to connect to AI server',
                'message' => $e->getMessage(),
                'insights' => [],
                'followups' => []
            ], 500);
        }
    }

    public function uploadData(Request $request)
    {
        try {
            $response = Http::attach(
                'file', 
                file_get_contents($request->file('file')),
                $request->file('file')->getClientOriginalName()
            )->post('http://localhost:5000/reload-data');

            return response()->json($response->json());

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to upload data',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}