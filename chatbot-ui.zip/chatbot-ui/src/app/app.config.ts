import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { routes } from './app.routes';
import { provideCharts, withDefaultRegisterables } from 'ng2-charts';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(),
    provideAnimations(),
    provideCharts(withDefaultRegisterables()),
    {
      provide: 'businessData',
      useValue: {
        sales: [3.2, 3.8, 4.5, 5.1],
        customers: [1200, 1350, 1500, 1850],
        growth: '15% QoQ',
        periods: ['Q1', 'Q2', 'Q3', 'Q4']
      }
    }
  ]
};