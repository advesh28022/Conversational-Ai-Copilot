import { Component, Input, OnChanges, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-bi-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="chart-container">
      <canvas #chartCanvas></canvas>
    </div>
  `,
  styles: [`
    .chart-container {
      position: relative;
      height: 400px;
      width: 100%;
    }
  `]
})
export class BiDashboardComponent implements OnChanges, AfterViewInit {
  @Input() visualizationData: any;
  @ViewChild('chartCanvas') private chartCanvas!: ElementRef;
  private chart: Chart | null = null;

  constructor() {
    Chart.register(...registerables);
  }

  ngAfterViewInit() {
    this.renderChart();
  }

  ngOnChanges() {
    this.renderChart();
  }

  private renderChart() {
    if (!this.visualizationData || !this.chartCanvas?.nativeElement) {
      return;
    }

    const ctx = this.chartCanvas.nativeElement.getContext('2d');
    if (!ctx) return;

    // Destroy previous chart if exists
    if (this.chart) {
      this.chart.destroy();
      this.chart = null;
    }

    console.log('Rendering chart with data:', this.visualizationData);

    // Set default options
    const defaultOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: this.visualizationData.options?.title?.text || 'Aviation Data',
          font: {
            size: 16
          }
        }
      },
      scales: {
        y: {
          beginAtZero: this.visualizationData.type !== 'line'
        }
      }
    };

    // Merge with provided options
    const options = {
      ...defaultOptions,
      ...(this.visualizationData.options || {})
    };

    this.chart = new Chart(ctx, {
      type: this.visualizationData.type,
      data: this.visualizationData.data,
      options: options
    });
  }

  ngOnDestroy() {
    if (this.chart) {
      this.chart.destroy();
    }
  }
}