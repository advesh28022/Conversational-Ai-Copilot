import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class VoiceRecognitionService {
  private recognition: any;
  text$ = new Subject<string>();
  isStopped = new Subject<boolean>();

  init() {
    const { webkitSpeechRecognition, SpeechRecognition } = window as any;
    this.recognition = new (webkitSpeechRecognition || SpeechRecognition)();
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';

    this.recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0].transcript)
        .join('');
      this.text$.next(transcript);
    };

    this.recognition.onerror = (event: any) => {
      console.error('Voice recognition error', event.error);
      this.isStopped.next(true);
    };

    this.recognition.onend = () => {
      this.isStopped.next(true);
    };
  }

  start() {
    this.isStopped.next(false);
    this.recognition.start();
  }

  stop() {
    this.isStopped.next(true);
    this.recognition.stop();
  }
}