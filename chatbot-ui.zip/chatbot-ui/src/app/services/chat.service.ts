import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface ChatResponse {
  response: string;
  visualization?: any;
  followups?: string[];
  insights?: string[];
  quick_actions?: {text: string, query: string}[];
  error?: boolean;
}

@Injectable({ providedIn: 'root' })
export class ChatService {
  private apiUrl = 'http://localhost:5000/process'; // Direct to Flask
  private uploadUrl = 'http://localhost:5000/reload-data';

  constructor(private http: HttpClient) {}

  processQuery(query: string): Observable<ChatResponse> {
    return this.http.post<ChatResponse>(this.apiUrl, { query }).pipe(
      map(response => this.formatResponse(response)),
      catchError(error => this.handleError(error))
    );
  }

  uploadData(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post(this.uploadUrl, formData);
  }

  private formatResponse(response: ChatResponse): ChatResponse {
    if (!response) return { 
      response: 'No response from server', 
      error: true,
      insights: [],
      followups: []
    };
    
    return {
      ...response,
      response: this.enrichText(response.response),
      followups: response.followups?.map(fq => this.enrichText(fq)) || [],
      insights: response.insights?.map(insight => this.enrichText(insight)) || []
    };
  }

  private enrichText(text: string): string {
    if (!text) return text;
    return text
      .replace(/→/g, '➔')
      .replace(/(\d+\.?\d*)%/g, '<strong class="highlight-percent">$1%</strong>')
      .replace(/\$(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/g, '<span class="highlight-currency">$$$1</span>')
      .replace(/\n/g, '<br>');
  }

  private handleError(error: any): Observable<ChatResponse> {
    console.error('API Error:', error);
    return of({
      response: "⚠️ Unable to connect to the Co-Pilot service. Please try again later.",
      error: true,
      insights: ["Connection error"],
      followups: ["Retry →", "Check server status →"]
    });
  }
}