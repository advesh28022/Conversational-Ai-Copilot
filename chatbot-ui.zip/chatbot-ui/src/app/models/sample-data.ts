// src/app/models/sample-data.ts
export const BusinessData = {
  sales: {
    quarterly: [
      { quarter: 'Q1', revenue: 3200000, growth: '5%' },
      { quarter: 'Q2', revenue: 3800000, growth: '12%' },
      { quarter: 'Q3', revenue: 4500000, growth: '15%' },
      { quarter: 'Q4', revenue: 5100000, growth: '18%' }
    ],
    byProduct: [
      { product: 'Enterprise Suite', revenue: 4200000 },
      { product: 'Professional Edition', revenue: 3200000 },
      { product: 'Starter Package', revenue: 1800000 }
    ],
    regions: {
      northAmerica: 6500000,
      europe: 4200000,
      asia: 2800000
    }
  },
  customers: {
    total: 1850,
    segments: {
      enterprise: 420,
      smb: 980,
      startup: 450
    },
    retention: '92%',
    churn: '5.2%'
  },
  operations: {
    cogs: 2800000,
    expenses: 1850000,
    profitMargin: '32%'
  }
};