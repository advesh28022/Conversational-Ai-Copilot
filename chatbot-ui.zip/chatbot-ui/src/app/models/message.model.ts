export interface Message {
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  context?: string;
  insights?: string[];
  visualization?: string;
  followUpQuestions?: string[];  // Add this property
}