import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ChatService } from '../services/chat.service';
import { BiDashboardComponent } from '../components/bi-dashboard/bi-dashboard.component';
import { ErrorStateMatcher } from '@angular/material/core';

interface ChatMessage {
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  followUpQuestions?: string[];
  insights?: string[];
}

export class NoErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(): boolean {
    return false;
  }
}

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    BiDashboardComponent,
    DatePipe
  ],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit {
  @ViewChild('messageContainer') private messageContainer!: ElementRef;

  chatForm: FormGroup;
  messages: ChatMessage[] = [];
  isLoading = false;
  isListening = false;
  currentVizData: any = null;
  currentInsights: string[] = [];
  noErrorStateMatcher = new NoErrorStateMatcher();

  constructor(
    private fb: FormBuilder,
    private chatService: ChatService,
    private snackBar: MatSnackBar
  ) {
    this.chatForm = this.fb.group({
      message: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.addBotMessage(
      "Hello! I'm your Ai Co-Pilot. Ask me anything about aviation data.",
      ["Show FAAN throughput", "Display Air Peace load factor", "View NCAA compliance"]
    );
  }

  sendMessage(message?: string) {
    const userMessage = message || this.chatForm.value.message;
    
    if (!userMessage || this.isLoading) return;

    // Clear previous messages except the initial greeting
    this.messages = this.messages.filter(m => m.sender === 'bot' && m.text.includes("Hello!"));
    
    this.addUserMessage(userMessage);
    this.chatForm.reset({ message: '' });
    this.isLoading = true;
    this.currentVizData = null;

    this.chatService.processQuery(userMessage).subscribe({
      next: (response: any) => {
        this.addBotMessage(
          response.response,
          response.followups,
          response.insights
        );
        
        if (response.visualization) {
          this.currentVizData = response.visualization;
        }

        this.isLoading = false;
        this.scrollToBottom();
      },
      error: (error: any) => {
        this.addBotMessage(
          "Sorry, I encountered an error processing your request.",
          ["Try again", "Ask something else"]
        );
        this.isLoading = false;
        this.scrollToBottom();
      }
    });
  }

  quickQuestion(question: string) {
    this.sendMessage(question);
  }

  toggleVoiceInput() {
    this.isListening = !this.isListening;
    if (this.isListening) {
      this.snackBar.open('Voice input is not implemented yet', 'OK', {
        duration: 3000
      });
      this.isListening = false;
    }
  }

  private addUserMessage(text: string) {
    this.messages.push({
      text: text,
      sender: 'user',
      timestamp: new Date()
    });
    this.scrollToBottom();
  }

  private addBotMessage(
    text: string,
    followUpQuestions?: string[],
    insights?: string[]
  ) {
    this.messages.push({
      text: text,
      sender: 'bot',
      timestamp: new Date(),
      followUpQuestions: followUpQuestions,
      insights: insights
    });
    this.currentInsights = insights || [];
    this.scrollToBottom();
  }

  private scrollToBottom() {
    setTimeout(() => {
      try {
        this.messageContainer.nativeElement.scrollTop = 
          this.messageContainer.nativeElement.scrollHeight;
      } catch (err) {
        console.error('Scroll error:', err);
      }
    }, 100);
  }

  handleFileUpload(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      this.chatService.uploadData(file).subscribe({
        next: (res: any) => {
          this.snackBar.open('Data reloaded successfully!', 'OK', {
            duration: 3000
          });
        },
        error: (err: any) => {
          this.snackBar.open('Failed to upload data', 'OK', {
            duration: 3000
          });
        }
      });
    }
  }
}